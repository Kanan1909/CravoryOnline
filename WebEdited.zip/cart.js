// Function to add item to cart
function addToCart(name, price, quantity) {
    var cartItemsDiv = document.getElementById('cart-items');
  
    var cartItemDiv = document.createElement('div');
    cartItemDiv.classList.add('cart-item');
  
    var itemImage = document.createElement('img');
    itemImage.src = 'images/brownie/' + name.toLowerCase().replace(/ /g, '') + '.png';
    itemImage.alt = name;
  
    var itemDetailsDiv = document.createElement('div');
    var itemName = document.createElement('h2');
    itemName.textContent = name;
    var itemPrice = document.createElement('p');
    itemPrice.textContent = 'Price: Rs. ' + (price * quantity).toFixed(2);
    var itemQuantity = document.createElement('p');
    itemQuantity.textContent = 'Quantity: ' + quantity;
  
    itemDetailsDiv.appendChild(itemName);
    itemDetailsDiv.appendChild(itemPrice);
    itemDetailsDiv.appendChild(itemQuantity);
  
    cartItemDiv.appendChild(itemImage);
    cartItemDiv.appendChild(itemDetailsDiv);
  
    cartItemsDiv.appendChild(cartItemDiv);
  
    updateTotal(price * quantity);
  }
  
  // Function to update total price
  function updateTotal(amount) {
    var totalPriceDiv = document.getElementById('total-price');
    var currentTotal = parseFloat(totalPriceDiv.textContent.replace('Total: Rs. ', '')) || 0;
    var newTotal = currentTotal + amount;
    totalPriceDiv.textContent = 'Total: Rs. ' + newTotal.toFixed(2);
  }
  